# PUBAFRICA.AFRICA — Prototype V1

Prototype frontend créé pour démarrer la construction de la plateforme PUBAFRICA.

## Contenu
- `index.html` : page d'accueil, annuaire, services et tarifs.
- `dashboard.html` : prototype de l'espace entreprise.
- `admin.html` : prototype du tableau de bord administrateur.
- `styles.css` : design responsive.
- `app.js` : recherche/filtrage et interactions simples.

## Lancer le prototype
1. Décompresser le dossier.
2. Ouvrir `index.html` dans Chrome, Edge ou Firefox.
3. Tester les boutons « Promouvoir mon entreprise » et « Connexion ».

## Prochaine étape technique
Ce prototype est une interface (frontend). Il faut ensuite connecter :
- authentification réelle ;
- base de données ;
- stockage des images/vidéos ;
- gestion des campagnes ;
- validation administrateur ;
- paiements Mobile Money/cartes ;
- statistiques réelles ;
- sécurité et hébergement.

Le domaine `.africa` est administré par Registry.Africa. Vérifier la disponibilité de `pubafrica.africa` auprès du registre/registrar avant achat.
